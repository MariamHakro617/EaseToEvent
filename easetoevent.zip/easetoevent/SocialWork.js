import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TextInput, TouchableOpacity } from 'react-native';
import GradientBackground from './GradientBackground';

const SocialWork = () => {
  // Event Data
  const events = [
    { id: 1, title: 'Environmental Clean-up Campaigns', image: 'https://example.com/cleanup.jpg' },
    { id: 2, title: 'Blood Donation Drives', image: 'https://example.com/blood-donation.jpg' },
    { id: 3, title: 'Educational Workshops for Underprivileged', image: 'https://example.com/education-workshop.jpg' },
    { id: 4, title: 'Senior Citizen Support Programs', image: 'https://example.com/senior-support.jpg' },
    { id: 5, title: 'Food Distribution Drives', image: 'https://example.com/food-distribution.jpg' },
    { id: 6, title: 'Health Awareness Campaigns', image: 'https://example.com/health-awareness.jpg' },
  ];

  // State for Search Input
  const [searchText, setSearchText] = useState('');

  // Filter Events Based on Search Input
  const filteredEvents = events.filter(event =>
    event.title.toLowerCase().includes(searchText.toLowerCase())
  );

  return (
    <View style={styles.container}>
      {/* Gradient Background */}
      <GradientBackground />

      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchBar}
          placeholder="Search Social Work Events"
          placeholderTextColor="#aaa"
          value={searchText}
          onChangeText={text => setSearchText(text)} // Update searchText state
        />
      </View>

      {/* Events List */}
      <ScrollView contentContainerStyle={styles.contentContainer}>
        {filteredEvents.map(event => (
          <View key={event.id} style={styles.eventContainer}>
            <Image
              source={{ uri: event.image }}
              style={styles.eventImage}
            />
            <Text style={styles.eventTitle}>{event.title}</Text>
            <TouchableOpacity style={styles.button}>
              <Text style={styles.buttonText}>Let's Organize</Text>
            </TouchableOpacity>
          </View>
        ))}
        {/* If no events match */}
        {filteredEvents.length === 0 && (
          <Text style={styles.noResultText}>No events found.</Text>
        )}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  searchContainer: {
    paddingTop: 50,
    paddingHorizontal: 20,
    paddingBottom: 10,
  },
  searchBar: {
    backgroundColor: '#fff',
    borderRadius: 20,
    height: 40,
    paddingHorizontal: 15,
    fontSize: 16,
    color: '#000',
    elevation: 3,
  },
  contentContainer: {
    paddingBottom: 30,
  },
  eventContainer: {
    backgroundColor: '#fff',
    borderRadius: 10,
    marginHorizontal: 20,
    marginBottom: 20,
    elevation: 3,
    overflow: 'hidden',
  },
  eventImage: {
    width: '100%',
    height: 150,
  },
  eventTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginVertical: 10,
    marginHorizontal: 10,
  },
  button: {
    backgroundColor: '#007bff',
    paddingVertical: 10,
    borderRadius: 5,
    marginHorizontal: 10,
    marginBottom: 10,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  noResultText: {
    textAlign: 'center',
    color: '#333',
    fontSize: 16,
    marginTop: 20,
  },
});

export default SocialWork;
