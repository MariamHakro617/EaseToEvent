import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import GradientBackground from './GradientBackground'; // Gradient Background for consistency
import Icon from 'react-native-vector-icons/MaterialIcons'; // Importing MaterialIcons for icons

const AboutUsScreen = () => {
  const cards = [
    { title: 'About Us', icon: 'info', description: 'EaseToEvent is an app designed for seamless event management.' },
    { title: 'How it works', icon: 'build', description: 'We provide an easy-to-use platform for event booking and organizing.' },
    { title: 'Our team', icon: 'school', description: 'Learn more about.' },
    { title: 'How to use App', icon: 'person-add', description: 'Sign up and create your account to start booking events.' },
    { title: 'Contact Us', icon: 'contact-mail', description: 'Get in touch with us for more information or support.' },
  ];

  return (
    <View style={styles.container}>
      {/* Gradient Background */}
      <GradientBackground />

      {/* Scrollable Content */}
      <ScrollView contentContainerStyle={styles.cardsContainer}>
        {cards.map((card, index) => (
          <View key={index} style={styles.card}>
            <Icon name={card.icon} size={40} color="#FF6F61" />
            <Text style={styles.cardTitle}>{card.title}</Text>
            <Text style={styles.cardDescription}>{card.description}</Text>
            <TouchableOpacity style={styles.learnMoreButton}>
              <Text style={styles.learnMoreText}>Learn more</Text>
            </TouchableOpacity>
          </View>
        ))}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  cardsContainer: {
    paddingBottom: 20, // Add bottom padding for scrollability
    alignItems: 'center', // Center the cards horizontally
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 20,
    marginVertical: 10,
    width: '90%',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 5,
  },
  cardTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 10,
  },
  cardDescription: {
    fontSize: 14,
    color: '#555',
    textAlign: 'center',
    marginTop: 10,
    marginBottom: 15,
  },
  learnMoreButton: {
    backgroundColor: '#FF6F61',
    paddingVertical: 8,
    paddingHorizontal: 20,
    borderRadius: 25,
  },
  learnMoreText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default AboutUsScreen;
