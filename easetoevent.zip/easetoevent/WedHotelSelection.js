import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput, TouchableOpacity, Image } from 'react-native';
import GradientBackground from './GradientBackground';

const WedHotelSelection = ({ route, navigation }) => {
  const { eventTitle } = route.params;

  // Extended list of hotels with various sizes
  const hotels = [
    { id: 1, name: 'Grand Palace Hotel', location: 'Mirpurkhas', image: require('./assets/grandpalace.jpg')},
    { id: 2, name: 'Hotel Mirpur', location: 'Mirpurkhas' },//image: require('./assets/hotelmirpur.jpg') },
    { id: 3, name: 'Garden Inn Hotel', location: 'Mirpurkhas' },//image: require('./assets/gardeninn.jpg') },
    { id: 4, name: 'Silver Sands Hotel', location: 'Mirpurkhas'},// image: require('./assets/silversands.jpg') },
    { id: 5, name: 'Grand Garden Resort', location: 'Garden'},//image: require('./assets/grandgarden.jpg') },
    { id: 6, name: 'Alwen Hotel & Resort', location: 'Garden'},// image: require('./assets/alwenhotel.jpg') },
    { id: 7, name: 'Sunset View Hotel', location: 'Mirpurkhas'},// image: require('./assets/sunsetview.jpg') },
    { id: 8, name: 'Parkside Suites', location: 'Mirpurkhas'},// image: require('./assets/parksidesuites.jpg') },
    { id: 9, name: 'Oceanic Bay Resort', location: 'Alwen'},// image: require('./assets/oceanicbay.jpg') },
    { id: 10, name: 'Mountain Peak Hotel', location: 'Alwen'}// image: require('./assets/mountainpeak.jpg') },
  ];

  // State for search input
  const [searchText, setSearchText] = useState('');

  // Filter hotels based on search input
  const filteredHotels = hotels.filter(hotel =>
    hotel.name.toLowerCase().includes(searchText.toLowerCase())
  );

  return (
    <View style={styles.container}>
      <GradientBackground />

      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchBar}
          placeholder="Search hotels"
          placeholderTextColor="#aaa"
          value={searchText}
          onChangeText={text => setSearchText(text)} // Update searchText state
        />
      </View>

      <ScrollView contentContainerStyle={styles.contentContainer}>
        {filteredHotels.length > 0 ? (
          filteredHotels.map(hotel => (
            <View key={hotel.id} style={styles.hotelContainer}>
              <Image source={hotel.image} style={styles.hotelImage} />
              <Text style={styles.hotelName}>{hotel.name}</Text>
              <Text style={styles.hotelLocation}>{hotel.location}</Text>

              <TouchableOpacity
                style={styles.button}
                onPress={() => navigation.navigate('GrandPalace', { hotel })} // Navigate to HotelDetail screen
              >
                <Text style={styles.buttonText}>Hotel Details</Text>
              </TouchableOpacity>
            </View>
          ))
        ) : (
          <Text style={styles.noResultText}>No hotels found.</Text>
        )}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  searchContainer: {
    paddingTop: 50,
    paddingHorizontal: 20,
    paddingBottom: 10,
  },
  searchBar: {
    backgroundColor: '#fff',
    borderRadius: 20,
    height: 40,
    paddingHorizontal: 15,
    fontSize: 16,
    color: '#000',
    elevation: 3,
  },
  contentContainer: {
    paddingBottom: 30,
  },
  hotelContainer: {
    backgroundColor: '#fff',
    borderRadius: 10,
    marginHorizontal: 20,
    marginBottom: 20,
    elevation: 3,
    padding: 10,
  },
  hotelImage: {
    width: '100%',
    height: 150,
    borderRadius: 10,
    marginBottom: 10,
  },
  hotelName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  hotelLocation: {
    fontSize: 14,
    color: '#777',
    marginBottom: 10,
  },
  button: {
    backgroundColor: '#007bff',
    paddingVertical: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  noResultText: {
    textAlign: 'center',
    color: '#333',
    fontSize: 16,
    marginTop: 20,
  },
});

export default WedHotelSelection;
