import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, Image, FlatList, TouchableOpacity, ScrollView } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import GradientBackground from './GradientBackground';

const HomeScreen = ({ navigation }) => {
  const categories = [
    { id: 1, name: 'Weddings & Celebrations', image: require('./assets/wedding.jpg') },
    { id: 2, name: 'Corporate Events', image: require('./assets/corporate.jpg') },
    { id: 3, name: 'Educational Events', image: require('./assets/educational.jpg') },
    { id: 4, name: 'Entertainment Events', image: require('./assets/entretainment.jpg') },
    { id: 5, name: 'Sports & Fitness', image: require('./assets/sports.jpg') },
    { id: 6, name: 'Religious Events', image: require('./assets/religion.png') },
    { id: 7, name: 'Social Work', image: require('./assets/socialwork.jpg') },
    { id: 8, name: 'Technology', image: require('./assets/technology.jpg') },
  ];

  const [searchQuery, setSearchQuery] = useState('');
  const [filteredCategories, setFilteredCategories] = useState([]);

  const handleSearch = (query) => {
    setSearchQuery(query);
    const filtered = categories.filter((category) =>
      category.name.toLowerCase().includes(query.toLowerCase())
    );
    setFilteredCategories(filtered);
  };

  const displayCategories =
    filteredCategories.length > 0 ? filteredCategories : categories;

  return (
    <View style={styles.container}>
      {/* Gradient Background */}
      <GradientBackground />

      {/* Top Bar */}
      <View style={styles.topBar}>
        <TouchableOpacity onPress={() => navigation.openDrawer()}>
          <Icon name="menu" size={30} color="#fff" />
        </TouchableOpacity>
        <View style={styles.searchContainer}>
          <Icon name="search" size={22} color="#aaa" style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search categories"
            placeholderTextColor="#aaa"
            value={searchQuery}
            onChangeText={handleSearch}
          />
        </View>
      </View>

      {/* Category List with ScrollView */}
      <ScrollView contentContainerStyle={styles.categoryList}>
        <FlatList
          data={displayCategories}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            <View style={styles.categoryItem}>
              <Image source={item.image} style={styles.categoryImage} />
              <Text style={styles.categoryText}>{item.name}</Text>
              <TouchableOpacity
                style={styles.button}
                onPress={() => {
                  if (item.name === 'Weddings & Celebrations') {
                    navigation.navigate('WeddingsAndCelebrations');
                  }
                  if (item.name === 'Corporate Events') {
                    navigation.navigate('CorporateEvents');
                  }
                  if (item.name === 'Educational Events') {
                    navigation.navigate('EducationalEvents');
                  }
                  if (item.name === 'Entertainment Events') {
                    navigation.navigate('EntertainmentEvents');
                  }
                  if (item.name === 'Religious Events') {
                    navigation.navigate('ReligiousEvents');
                  }
                  if (item.name === 'Sports & Fitness') {
                    navigation.navigate('SportsFitness');
                  }
                  if (item.name === 'Social Work') {
                    navigation.navigate('SocialWork');
                  }
                  if (item.name === 'Technology') {
                    navigation.navigate('Technology');
                  }
                }}
              >
                <Text style={styles.buttonText}>View Categories</Text>
              </TouchableOpacity>
            </View>
          )}
        />
        {/* Added extra padding at the bottom to ensure visibility of last button */}
        <View style={{ paddingBottom: 50 }} />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    position: 'absolute',
    top: 30,
    left: 0,
    right: 0,
    zIndex: 10,
    backgroundColor: 'rgba(0,0,0,0.5)',
    borderRadius: 10,
  },
  searchContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 25,
    marginLeft: 10,
    paddingHorizontal: 15,
    height: 40,
  },
  searchIcon: {
    marginRight: 10,
  },
  searchInput: {
    flex: 1,
    color: '#333',
    fontSize: 16,
  },
  categoryList: {
    marginTop: 100,
    paddingHorizontal: 10,
    // Ensures there's enough space at the bottom for the last category button
    paddingBottom: 100,
  },
  categoryItem: {
    backgroundColor: '#fff',
    padding: 10,
    marginVertical: 10,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 2,
    alignItems: 'center',
    width: '100%',
  },
  categoryImage: {
    width: '100%',
    height: 150,
    borderRadius: 10,
    resizeMode: 'cover',
    marginBottom: 10,
  },
  categoryText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
    textAlign: 'center',
  },
  button: {
    backgroundColor: '#007BFF',
    borderRadius: 25,
    paddingVertical: 10,
    paddingHorizontal: 20,
    marginBottom: 10,  // Added margin to prevent overlap
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});

export default HomeScreen;
