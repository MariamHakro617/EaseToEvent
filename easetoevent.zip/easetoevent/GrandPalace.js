import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView, TouchableOpacity } from 'react-native';
import GradientBackground from './GradientBackground';
import MapView, { Marker } from 'react-native-maps';

const GrandPalace = ({ route }) => {
  const { hotel } = route.params;

  return (
    <View style={styles.container}>
      <GradientBackground />

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Hotel Name */}
        <Text style={styles.hotelHeading}>{hotel.name}</Text>

        {/* Hotel Image */}
        <Image
          source={require('./assets/grandpalace.jpg')} // Update with your image path
          style={styles.hotelImage}
        />

        {/* Hotel Details */}
        <View style={styles.detailsContainer}>
          <Text style={styles.detailsTitle}>Event Types</Text>
          <Text style={styles.detailsText}>
            Weddings, Corporate Events, Private Parties, Conferences, and more.
          </Text>

          <Text style={styles.detailsTitle}>Services Provided</Text>
          <Text style={styles.detailsText}>
            Catering, Decoration, Audio-Visual Equipment, Dedicated Event Planners, and On-Site Accommodation.
          </Text>

          <Text style={styles.detailsTitle}>Pricing</Text>
          <Text style={styles.detailsText}>
            Booking starts from $2000 for small events and goes up to $20,000 for larger events.
          </Text>

          <Text style={styles.detailsTitle}>Operating Days</Text>
          <Text style={styles.detailsText}>
            Monday to Sunday: 9:00 AM - 11:00 PM
          </Text>
        </View>

        {/* Google Maps Integration */}
        <View style={styles.mapContainer}>
          <Text style={styles.detailsTitle}>Location</Text>
          <MapView
            style={styles.map}
            initialRegion={{
              latitude: hotel.lat,
              longitude: hotel.lng,
              latitudeDelta: 0.02,
              longitudeDelta: 0.02,
            }}
          >
            <Marker coordinate={{ latitude: hotel.lat, longitude: hotel.lng }} />
          </MapView>
        </View>

        {/* Book Now Button */}
        <TouchableOpacity style={styles.button} onPress={() => alert(`Booking ${hotel.name}`)}>
          <Text style={styles.buttonText}>Book Now</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  scrollContent: {
    paddingBottom: 30,
  },
  hotelHeading: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginVertical: 10,
  },
  hotelImage: {
    width: '100%',
    height: 250,
    marginBottom: 20,
  },
  detailsContainer: {
    marginHorizontal: 20,
    marginBottom: 20,
  },
  detailsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#007bff',
    marginTop: 10,
  },
  detailsText: {
    fontSize: 16,
    color: '#333',
    marginVertical: 5,
    lineHeight: 22,
  },
  mapContainer: {
    marginHorizontal: 20,
    marginTop: 20,
  },
  map: {
    width: '100%',
    height: 200,
    borderRadius: 10,
  },
  button: {
    backgroundColor: '#007bff',
    paddingVertical: 12,
    borderRadius: 5,
    marginTop: 20,
    alignItems: 'center',
    marginHorizontal: 20,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default GrandPalace;
