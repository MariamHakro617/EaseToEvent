import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import GradientBackground from './GradientBackground'; // Importing GradientBackground component
import Icon from 'react-native-vector-icons/MaterialIcons'; // For icons

const UserScreen = () => {
  return (
    <View style={styles.container}>
      {/* Gradient Background */}
      <GradientBackground />

      {/* Profile Section */}
      <View style={styles.profileContainer}>
        <Image
          source={require('./assets/avatar.jpg')} // Replace with your avatar image path
          style={styles.avatar}
        />
        <Text style={styles.username}>Mariam</Text>
        <Text style={styles.contactInfo}>8967452743</Text>
        <Text style={styles.contactInfo}>mhakro617@gmail.com</Text>
      </View>

      {/* Options Section */}
      <View style={styles.optionsContainer}>
        <Option icon="history" label="Order History" />
        <Option icon="location-on" label="Shipping Address" />
        <Option icon="add-box" label="Create Request" />
        <Option icon="description" label="Privacy Policy" />
        <Option icon="settings" label="Settings" />
        <Option icon="exit-to-app" label="Log out" />
      </View>
    </View>
  );
};

const Option = ({ icon, label }) => (
  <TouchableOpacity style={styles.option}>
    <Icon name={icon} size={24} color="#FF6F61" />
    <Text style={styles.optionText}>{label}</Text>
    <Icon name="chevron-right" size={24} color="#FF6F61" />
  </TouchableOpacity>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  profileContainer: {
    alignItems: 'center',
    marginBottom: 30,
  },
  avatar: {
    top: 40,
    width: 100,
    height: 100,
    borderRadius: 50,
    borderWidth: 3,
    borderColor: '#fff',
    marginBottom: 10,
  },
  username: {
    top: 90,
    fontSize: 22,
    fontWeight: 'bold',
    color: '#fff',
  },
  contactInfo: {
    fontSize: 16,
    color: '#fff',
    marginBottom: 5,
  },
  optionsContainer: {
    marginTop: 30,
  },
  option: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#FFB4A2',
  },
  optionText: {
    flex: 1,
    fontSize: 18,
    color: '#fff',
    marginLeft: 10,
  },
});

export default UserScreen;
