import React, { useEffect } from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import Svg, { Defs, RadialGradient, Stop, Circle } from 'react-native-svg'; // Import SVG components

export default function SplashScreen({ navigation }) {
  useEffect(() => {
    setTimeout(() => {
      navigation.replace('Login'); // Navigate to Home Screen after 3 seconds
    }, 3000);
  }, [navigation]);

  return (
    <View style={styles.container}>
      <Svg height="100%" width="100%" viewBox="0 0 100 100" style={styles.svg}>
        <Defs>
          {/* Define Conic Gradient (this is an approximation using a circle and gradient) */}
          <RadialGradient id="conicGradient" cx="50%" cy="50%" r="50%" fx="50%" fy="50%">
            <Stop offset="0%" stopColor="purple" />
            <Stop offset="50%" stopColor="lightpink" />
            <Stop offset="100%" stopColor="peech" />
            <Stop offset="150%" stopColor="lightpurple" />
          </RadialGradient>
        </Defs>
        <Circle cx="100" cy="50" r="150" fill="url(#conicGradient)" />
      </Svg>

      <View style={styles.overlay}>
        <Image
          source={require('./assets/logi.png')} // Replace with your local asset path
          style={styles.logo}
        />
        <Text style={styles.title}>Welcome to EaseToEvent</Text>
        
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  
  
  svg: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1,
  },
  logo: {
    width: 150,
    height: 150,
    marginBottom: 20,
    borderRadius: 20,
  },
  title: {
    fontSize: 24,
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontStyle: '',
    textShadowRadius:22,
  },
});