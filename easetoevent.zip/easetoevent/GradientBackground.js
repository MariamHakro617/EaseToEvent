import React from 'react';
import { View, StyleSheet } from 'react-native';
import Svg, { Defs, RadialGradient, Stop, Circle } from 'react-native-svg'; // Import SVG components

const GradientBackground = () => {
  return (
    <View style={styles.container}>
      <Svg height="100%" width="100%" viewBox="0 0 100 100" style={styles.svg}>
        <Defs>
          {/* Define Radial Gradient with colors from pink family */}
          <RadialGradient id="conicGradient" cx="50%" cy="50%" r="50%" fx="50%" fy="50%">
            <Stop offset="0%" stopColor="purple" />
            <Stop offset="50%" stopColor="lightpink" />
            <Stop offset="100%" stopColor="peech" />
            <Stop offset="150%" stopColor="lightpurple" />
          </RadialGradient>
        </Defs>
        <Circle cx="100" cy="50" r="150" fill="url(#conicGradient)" />
      </Svg>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  svg: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
});

export default GradientBackground;
