import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  Button,
  Alert,
  Image,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import GradientBackground from './GradientBackground'; // Import GradientBackground

const SignupScreen = ({ navigation }) => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // Save data to AsyncStorage
  const saveDataToAsyncStorage = async (key, value) => {
    try {
      await AsyncStorage.setItem(key, JSON.stringify(value));
      console.log(`${key} saved successfully!`);
    } catch (e) {
      console.error(`Failed to save ${key}: `, e);
    }
  };

  // Validation function
  const validateInputs = () => {
    const usernameRegex = /^[a-zA-Z][a-zA-Z0-9]{4,14}$/; // 5-15 chars, start with letter, no special chars
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; // Valid email format
    const passwordRegex =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$/; // Password strength rules

    if (!username.trim()) {
      Alert.alert('Validation Error', 'Username is required.');
      return false;
    }
    if (!usernameRegex.test(username)) {
      Alert.alert(
        'Validation Error',
        'Username must be 5-15 characters, start with a letter, and contain no special characters.'
      );
      return false;
    }
    if (!email.trim()) {
      Alert.alert('Validation Error', 'Email is required.');
      return false;
    }
    if (!emailRegex.test(email)) {
      Alert.alert('Validation Error', 'Please enter a valid email address.');
      return false;
    }
    if (!password.trim()) {
      Alert.alert('Validation Error', 'Password is required.');
      return false;
    }
    if (!passwordRegex.test(password)) {
      Alert.alert(
        'Validation Error',
        'Password must be at least 8 characters long, include one uppercase letter, one lowercase letter, one digit, and one special character.'
      );
      return false;
    }
    return true;
  };

  // Handle Signup
  const handleSignup = async () => {
    if (validateInputs()) {
      const userData = { username, email, password };
      await saveDataToAsyncStorage('user', userData); // Save user data to AsyncStorage
      Alert.alert('Success', 'Account created successfully!');
      navigation.replace('Drawer'); // Navigate to Home screen
    }
  };

  // Handle Login Navigation
  const handleLogin = () => {
    navigation.navigate('Login'); // Navigate to Login screen
  };

  return (
    <View style={styles.container}>
      <GradientBackground />
      <View style={styles.overlay}>
        {/* Add the logo */}
        <Image
          source={require('./assets/logi.png')} // Replace with your logo's path
          style={styles.logo}
          resizeMode="contain"
        />

        <Text style={styles.title}>Sign Up for EaseToEvent</Text>

        {/* Username Input */}
        <TextInput
          style={styles.input}
          placeholder="Username"
          value={username}
          onChangeText={setUsername}
        />

        {/* Email Input */}
        <TextInput
          style={styles.input}
          placeholder="Email"
          keyboardType="email-address"
          value={email}
          onChangeText={setEmail}
        />

        {/* Password Input */}
        <TextInput
          style={styles.input}
          placeholder="Password"
          secureTextEntry
          value={password}
          onChangeText={setPassword}
        />

        {/* Signup Button */}
        <Button title="Sign Up" onPress={handleSignup} />

        {/* Navigate to Login */}
        <Text style={styles.loginText} onPress={handleLogin}>
          Already have an account? Log In
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1,
    paddingHorizontal: 20,
  },
  logo: {
    width: 150, // Adjust the width as needed
    height: 150, // Adjust the height as needed
    marginBottom: 20,  // Adds spacing between logo and title
    borderRadius: 20, // Adds spacing between logo and title
  },
  title: {
    fontSize: 28,
    color: '#FFFFFF',
    fontWeight: 'bold',
    marginBottom: 30,
  },
  input: {
    width: '80%',
    height: 45,
    backgroundColor: '#fff',
    marginBottom: 15,
    borderRadius: 5,
    paddingHorizontal: 10,
  },
  loginText: {
    fontSize: 15,
    color: '#FFFFFF',
    marginTop: 15,
    textDecorationLine: 'underline',
     fontWeight: 'bold',
  },
});

export default SignupScreen;
