import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TextInput, TouchableOpacity } from 'react-native';
import GradientBackground from './GradientBackground';

const WeddingsAndCelebrations = ({ navigation }) => {
  const events = [
    { id: 1, title: 'Engagement Parties', image: require('./assets/engagement.jpg') },
    { id: 2, title: 'Wedding Ceremonies', image: require('./assets/wedding0.jpg') },
    { id: 3, title: 'Reception Parties', image: require('./assets/recieption.jpg') },
    { id: 4, title: 'Bridal Showers', image: 'https://example.com/bridal.jpg' },
    { id: 5, title: 'Bachelorette Parties', image: 'https://example.com/bachelorette.jpg' },
    { id: 6, title: 'Anniversaries', image: 'https://example.com/anniversary.jpg' },
  ];

  const [searchText, setSearchText] = useState('');

  const filteredEvents = events.filter(event =>
    event.title.toLowerCase().includes(searchText.toLowerCase())
  );

  return (
    <View style={styles.container}>
      <GradientBackground />

      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchBar}
          placeholder="Search categories"
          placeholderTextColor="#aaa"
          value={searchText}
          onChangeText={text => setSearchText(text)}
        />
      </View>

      <ScrollView contentContainerStyle={styles.contentContainer}>
        {filteredEvents.map(event => (
          <View key={event.id} style={styles.eventContainer}>
            <Image source={{ uri: event.image }} style={styles.eventImage} />
            <Text style={styles.eventTitle}>{event.title}</Text>
            <TouchableOpacity
              style={styles.button}
              onPress={() => navigation.navigate('WedHotelSelection', { eventTitle: event.title })}
            >
              <Text style={styles.buttonText}>Let's Organize</Text>
            </TouchableOpacity>
          </View>
        ))}
        {filteredEvents.length === 0 && (
          <Text style={styles.noResultText}>No events found.</Text>
        )}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  searchContainer: {
    paddingTop: 50,
    paddingHorizontal: 20,
    paddingBottom: 10,
  },
  searchBar: {
    backgroundColor: '#fff',
    borderRadius: 20,
    height: 40,
    paddingHorizontal: 15,
    fontSize: 16,
    color: '#000',
    elevation: 3,
  },
  contentContainer: {
    paddingBottom: 30,
  },
  eventContainer: {
    backgroundColor: '#fff',
    borderRadius: 10,
    marginHorizontal: 20,
    marginBottom: 20,
    elevation: 3,
    overflow: 'hidden',
  },
  eventImage: {
    width: '100%',
    height: 150,
  },
  eventTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginVertical: 10,
    marginHorizontal: 10,
  },
  button: {
    backgroundColor: '#007bff',
    paddingVertical: 10,
    borderRadius: 5,
    marginHorizontal: 10,
    marginBottom: 10,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  noResultText: {
    textAlign: 'center',
    color: '#333',
    fontSize: 16,
    marginTop: 20,
  },
});

export default WeddingsAndCelebrations;
