import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  Button,
  Alert,
  Image,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import GradientBackground from './GradientBackground'; // Import the GradientBackground component

const LoginScreen = ({ navigation }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  // Save data to AsyncStorage
  const saveDataToAsyncStorage = async (key, value) => {
    try {
      await AsyncStorage.setItem(key, JSON.stringify(value));
      console.log(`${key} saved successfully!`);
    } catch (e) {
      console.error(`Failed to save ${key}: `, e);
    }
  };

  // Validation function
  const validateInputs = () => {
    const usernameRegex = /^[a-zA-Z0-9]+$/; // Alphanumeric only
    if (!username.trim()) {
      Alert.alert('Validation Error', 'Username is required');
      return false;
    }
    if (!usernameRegex.test(username)) {
      Alert.alert('Validation Error', 'Username can only contain letters and numbers');
      return false;
    }
    if (!password.trim()) {
      Alert.alert('Validation Error', 'Password is required');
      return false;
    }
    if (password.length < 6) {
      Alert.alert('Validation Error', 'Password must be at least 6 characters long');
      return false;
    }
    return true;
  };

  // Handle login action
  const handleLogin = async () => {
    if (validateInputs()) {
      const userData = { username, password };
      await saveDataToAsyncStorage('user', userData); // Save user data to AsyncStorage
      navigation.replace('Drawer'); // Navigate to Home screen after successful login
    }
  };

  // Handle signup action
  const handleSignup = () => {
    navigation.navigate('Signup'); // Navigate to Signup screen
  };

  return (
    <View style={styles.container}>
      <GradientBackground /> {/* Apply the GradientBackground component */}
      <View style={styles.overlay}>
        {/* Add the logo */}
        <Image
          source={require('./assets/logi.png')} // Replace with your logo's path
          style={styles.logo}
          resizeMode="contain"
        />

        <Text style={styles.title}>Login to EaseToEvent</Text>

        {/* Username input */}
        <TextInput
          style={styles.input}
          placeholder="Username"
          value={username}
          onChangeText={setUsername}
        />

        {/* Password input */}
        <TextInput
          style={styles.input}
          placeholder="Password"
          secureTextEntry
          value={password}
          onChangeText={setPassword}
        />

        {/* Login and SignUp buttons */}
        <View style={styles.buttonContainer}>
          <View style={styles.buttonWrapper}>
            <Button title="Login" onPress={handleLogin} />
          </View>
          <View style={styles.buttonWrapper}>
            <Button title="Sign Up" onPress={handleSignup} />
            
          </View>
        </View>

        <Text style={styles.signuptext}>
              Signup to create your account!
            </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1,
    paddingHorizontal: 20, // To add padding for inputs
  },
  logo: {
    width: 150, // Adjust the width according to your design
    height: 150, // Adjust the height according to your design
    marginBottom: 20,
     borderRadius: 20, // Adds spacing between logo and title
  },
  title: {
    fontSize: 28,
    color: '#FFFFFF',
    fontWeight: 'bold',
    marginBottom: 30,
  },
  input: {
    width: '80%',
    height: 45,
    backgroundColor: '#fff',
    marginBottom: 15,
    borderRadius: 5,
    paddingHorizontal: 10,
  },
  signuptext: {
    fontSize: 15,
    color: '#FFFFFF',
    fontWeight: 'bold',
    marginBottom: 20,
    textDecorationLine: 'underline',
    //marginTop: 10,
    /*
    color: '#FFFFFF',
    marginTop: 15,
    marginInlineStart: 20,
    textDecorationLine: 'underline',
    textAlign: 'left', */
  },
  buttonContainer: {
    padding: 20, // Adds padding around the whole container
    alignItems: 'center',
  },
  buttonWrapper: {
    marginVertical: 10, // Adds vertical spacing between buttons
    width: '30%',
  },
});

export default LoginScreen;
