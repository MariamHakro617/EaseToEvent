import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import SplashScreen from './SplashScreen'; // Import SplashScreen
import HomeScreen from './HomeScreen'; // Import HomeScreen
import LoginScreen from './LoginScreen';
import SignUpScreen from './SignUpScreen';
import UserScreen from './UserScreen';
import AboutUsScreen from './AboutUsScreen';
import GradientBackground from './GradientBackground';
import { createDrawerNavigator } from '@react-navigation/drawer';

// Import all category screens
import WeddingsAndCelebrations from './WeddingsAndCelebrations';
import CorporateEvents from './CorporateEvents';
import EducationalEvents from './EducationalEvents';
import EntertainmentEvents from './EntertainmentEvents';
import ReligiousEvents from './ReligiousEvents';
import SocialWork from './SocialWork';
import SportsFitness from './SportsFitness';
import Technology from './Technology';


//import all hotel screens
import WedHotelSelection from './WedHotelSelection'; // Adjust if needed

//import hotel details screens
import GrandPalace from './GrandPalace';
const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();

// Drawer navigator to navigate between different screens
function DrawerNavigator() {
  return (
    <Drawer.Navigator
      screenOptions={{
        headerShown: false,
        drawerStyle: {
          backgroundColor: '#f9f9f9',
          width: 250,
        },
        drawerLabelStyle: {
          fontSize: 16,
          color: '#333',
        },
        drawerActiveTintColor: '#007BFF',
      }}
    >
      <Drawer.Screen
        name="Home"
        component={HomeScreen}
        options={{ title: 'Home' }}
      />
      <Drawer.Screen
        name="User"
        component={UserScreen}
        options={{ title: 'User Profile' }}
      />
      <Drawer.Screen
        name="AboutUs"
        component={AboutUsScreen}
        options={{ title: 'About Us' }}
      />
    </Drawer.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Splash" // First screen to show
        screenOptions={{
          headerShown: false, // Hide header from all screens
        }}
      >
        <Stack.Screen name="Splash" component={SplashScreen} />
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Signup" component={SignUpScreen} />
        <Stack.Screen name="GradientBackground" component={GradientBackground} />
        <Stack.Screen name="WedHotelSelection" component={WedHotelSelection} />
        <Stack.Screen name="GrandPalace" component={GrandPalace} />
        {/* DrawerNavigator Screen */}
        <Stack.Screen name="Drawer" component={DrawerNavigator} />

        {/* Category Screens (Stack Navigation) */}
        <Stack.Screen
          name="WeddingsAndCelebrations"
          component={WeddingsAndCelebrations}
        />
        <Stack.Screen
          name="CorporateEvents"
          component={CorporateEvents}
        />
        <Stack.Screen
          name="EducationalEvents"
          component={EducationalEvents}
        />
        <Stack.Screen
          name="EntertainmentEvents"
          component={EntertainmentEvents}
        />
        <Stack.Screen
          name="ReligiousEvents"
          component={ReligiousEvents}
        />
        <Stack.Screen name="SocialWork" component={SocialWork} />
        <Stack.Screen name="SportsFitness" component={SportsFitness} />
        <Stack.Screen name="Technology" component={Technology} />

        {/* HomeScreen (You can navigate to this from Drawer or Stack) */}
        <Stack.Screen name="Home" component={HomeScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
